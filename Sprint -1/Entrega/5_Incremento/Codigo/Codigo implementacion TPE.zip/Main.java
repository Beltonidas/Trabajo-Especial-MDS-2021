public class Main {
    public static void main(String[] args) {
        GestorCartonero gestorCartonero = new GestorCartonero();
        Secretaria s = new Secretaria(false, "Cecilia",gestorCartonero);
        BaseDatos BD = new BaseDatos("Hola", "Comoestas");
        ControladorLogin CL = new ControladorLogin(BD);
        InterfazLogin interfazLogin = new InterfazLogin(1,CL);
        interfazLogin.simularLogin(s);
        if (s.isEstadoLogin() == true){
            System.out.println("1");
        }
        else 
            System.out.println("0");
    }
}

public interface TipoVista {
    public abstract void desplegarMenu();
    public abstract void ingresarDatos();
}

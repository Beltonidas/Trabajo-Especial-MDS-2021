import java.util.Scanner;

public class GestorDeVistas {
    // IN-PROCESS
        public static void main(String[] args) {
            GestorCartonero gestorCartonero = new GestorCartonero();
            Secretaria s = new Secretaria(false, "Cecilia",gestorCartonero);
            BaseDatos BD = new BaseDatos("Hola", "Comoestas");
            ControladorLogin CL = new ControladorLogin(BD);
            InterfazLogin interfazLogin = new InterfazLogin(1,CL);
            interfazLogin.simularLogin(s);
            if (s.isEstadoLogin() == true){
                System.out.println("1");
            }
            else
                System.out.println("0");


        //Desplegar menu general, opcion 1: login, 2:ver ofertas transporte, 3: ver listado materiales
        // 4: ver instructivo.

            TipoVista vistasa = new VistaMenu();
            VistaMenu vistaMenu = new VistaMenu();
            vistasa = vistaMenu;

            System.out.println("Menu:");
            System.out.println("1: login");
            System.out.println("2: visualizar cartelera");
            System.out.println("3: ver listado materiales");
            System.out.println("4: ver instructivo");
            Scanner sc = new Scanner(System.in);
            String eleccion = sc.nextLine();
            APIsesion VS = new APIsesion();

            switch(eleccion)
            {
                case "1" :// Va a interfazLogin

                case "2" :// Se muestra la cartelera en pantalla

                case "3":// Se muestra el listado de materiales

                case "4":// Se muestra el instructivo

                default :
            }


        }
}

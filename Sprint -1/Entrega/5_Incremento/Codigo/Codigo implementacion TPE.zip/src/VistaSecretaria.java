import java.util.Scanner;

public class VistaSecretaria implements TipoVista{
    private Gestionar

    public VistaSecretaria() {
    }

    @Override
    public void desplegarMenu() {
        System.out.println("MenuSecretaria:");
        System.out.println("1: Gestionar Cartoneros");
        System.out.println("2: Gestionar Instructivo");
        System.out.println("3: Gestionar Materiales Reciclabes");
        Scanner sc = new Scanner(System.in);
        String eleccion = sc.nextLine();


        switch(eleccion)
        {
            case "1" :// se ingresan los datos, se manda un mensaje APi sesion que diga aggCartonero

            case "2" ://

            case "3"://

            default :
        }
    }

    @Override
    public void ingresarDatos() {

    }
}

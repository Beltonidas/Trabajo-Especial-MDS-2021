public class ControladorLogin {
    private BaseDatos baseDatos;

    public ControladorLogin(BaseDatos baseDatos) {
        this.baseDatos = baseDatos;
    }

    public BaseDatos getBaseDatos() {
        return baseDatos;
    }

    public void setBaseDatos(BaseDatos baseDatos) {
        this.baseDatos = baseDatos;
    }

    public boolean verificarLogin(String Usuario, String clave){
        return (baseDatos.getNombreUsuario().equals(Usuario) && baseDatos.getClave().equals(clave));
    }
}

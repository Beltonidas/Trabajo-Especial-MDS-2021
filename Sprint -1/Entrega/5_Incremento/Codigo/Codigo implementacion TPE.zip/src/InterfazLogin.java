import java.util.Scanner;

public class InterfazLogin implements TipoVista{
    private int idLogin;
    ControladorLogin login;

    public InterfazLogin(int idLogin, ControladorLogin login) {
        this.idLogin = idLogin;
        this.login = login;
    }

    public int getIdLogin() {
        return idLogin;
    }

    public void setIdLogin(int idLogin) {
        this.idLogin = idLogin;
    }

    public void dibujarLogin(){};

    public void comprobarSintaxysUsuario(String usuario){
        String palabra = usuario;
    }

    @Override
    public void desplegarMenu() {
    }

    @Override
    public void ingresarDatos() {
    }

    public void simularLogin(Secretaria secretaria){
        System.out.println("Si se quiere Logear tendra que ingresar el nombre de Usuario y la Clave");
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese su nombre de Usuario");
        String usuario = sc.nextLine();
        System.out.println("Ingrese su clave");
        String clave = sc.nextLine();
        //fin Reemplazar al descubrir como leer y comprobar caracter por caracter

        secretaria.setEstadoLogin(login.verificarLogin(usuario, clave));
    }
}

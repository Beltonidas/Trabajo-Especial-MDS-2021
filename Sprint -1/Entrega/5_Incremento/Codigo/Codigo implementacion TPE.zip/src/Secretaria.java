public class Secretaria {
    private boolean estadoLogin;
    private String nombre;
    private GestorCartonero gestorCartonero;

    public Secretaria(boolean estadoLogin, String nombre, GestorCartonero gestorCartonero) {
        this.estadoLogin = estadoLogin;
        this.nombre = nombre;
        this.gestorCartonero = gestorCartonero;
    }

    public Secretaria(boolean estadoLogin) {
        this.estadoLogin = estadoLogin;
    }

    public boolean isEstadoLogin() {
        return estadoLogin;
    }

    public void setEstadoLogin(boolean estadoLogin) {
        this.estadoLogin = estadoLogin;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void modificarCartonero( String nombre, String apellido, int dni, char vehiculo, String direccion, Cartonero aCambiar){
        //Hay que ver donde controlar la accesibilidad a esta actividad
        //AKA, no estamos controlando que la secretaria esté logeada
        if(estadoLogin) {
            gestorCartonero.modCartonero(nombre, apellido, dni, vehiculo, direccion, aCambiar);
        }
    }

    public Float kiloRegistradoCartonero(Cartonero cartonero){
        return gestorCartonero.getRegistroKilos().get(cartonero);
    }

}

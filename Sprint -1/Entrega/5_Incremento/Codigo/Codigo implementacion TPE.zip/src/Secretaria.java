public class Secretaria {
    private boolean estadoLogin;


    public Secretaria(boolean estadoLogin) {
        this.estadoLogin = estadoLogin;
    }

    public boolean isEstadoLogin() {
        return estadoLogin;
    }

    public void setEstadoLogin(boolean estadoLogin) {
        this.estadoLogin = estadoLogin;
    }

}

import java.util.Scanner;

public class VistaCartonero implements TipoVista{


    public VistaCartonero() {
    }

    //vista general manda un mensaje dar de alta a la clase GestorCartonero

    //VistaGeneral ----simularLogin()---> APIsesion ----simularLogin()----> InterfazLogin()
    //----------------------------------- APIsesion <----true---- InterfazLogin()
    //----------------------------------- APIsesion ----desplegarMenu()----> VistaSecretaria()
    //VistaGeneral <---vistaSecretaria--- APIsesion <----vistaSecretaria---- VistaSecretaria()
    //VistaGeneral ----vistaSecretaria--- APIsesion <----vistaSecretaria---- VistaSecretaria()




    //VistaGeneral ----darDeAlta()----> APIsesion ----darDeAlta()----> GestorCartonero
    //VistaGeneral <----vistaAlta---- APIsesion <----vistaAlta---- GestorCartonero

    @Override
    public void desplegarMenu() {
        System.out.println("Menu:");
        System.out.println("1: Dar de alta");
        System.out.println("2: Modificar Cartonero");
        System.out.println("3: Eliminar Cartonero");
        Scanner sc = new Scanner(System.in);
        String eleccion = sc.nextLine();


        switch(eleccion)
        {
            case "1" ://

            case "2" ://

            case "3"://

            case "4"://

            default :
        }
    }

    @Override
    public void ingresarDatos() {

    }
}

import java.util.Scanner;

public class VistaMenu implements TipoVista{


    public VistaMenu() {
        int iD=1;
    }

    @Override
    public void desplegarMenu() {
    }

    @Override
    public void ingresarDatos() {
    }
}

public class APIsesion {
    // se conecta con interfazLogin, y simula un login
    // si el login es true
}

















/*En ApiSesion:
boolean aggCartonero(Secretaria, DatosParaCartonero){}
zxc
Leon9713:50
boolean aggCartonero(Secretaria, DatosParaCartonero){
  if(secretaria.estaLogeada()){
    GestorDeCartoneros(DatosParaCartonero);
return true;
}else
  return false;
}



VistaSec logearse(Secretaria, pass, contraseña){
}








*/



